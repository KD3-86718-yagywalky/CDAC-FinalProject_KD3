package com.hotelbooking.service;

public class RoomServiceImpl {

}
